package com.example.customlistview

class Model (val title:String, val desc:String, val photo:Int )