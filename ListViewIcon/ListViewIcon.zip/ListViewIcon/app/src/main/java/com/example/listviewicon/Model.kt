package com.example.listviewicon

class Model (val title:String, val desc: String, val photo:Int)